import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


public class FollowDirections {
	
	private static String inputFile = "ActualInput.txt";
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File file = new File(inputFile);
		BufferedReader reader = null;
		
		try {
		    reader = new BufferedReader(new FileReader(file));
		    String text = null;

		    int x = 0;
		    int y = 0;
		    int direction = 0;
		    
		    while ((text = reader.readLine()) != null) {
//		    	System.out.println(text);
		    	
		    	String[] sp = text.split(" "); 
		    	if ("Move".equals(sp[0])) {
		    		switch (direction) {
		    		case 0:
		    			y += Integer.parseInt(sp[1]);
		    			break;
		    		case 1:
		    			y -= Integer.parseInt(sp[1]);
		    			break;
		    		case 2:
		    			x += Integer.parseInt(sp[1]);
		    			break;
		    		case 3:
		    			x -= Integer.parseInt(sp[1]);
		    			break;
		    		}
		    	} else {
		    		if (sp[1].equalsIgnoreCase("left")) {
		    			switch (direction) {
		    			case 0:
		    				direction = 2;
		    				break;
		    			case 1:
		    				direction = 3;
		    				break;
		    			case 2:
		    				direction = 1;
		    				break;
		    			case 3:
		    				direction = 0;
		    				break;
		    			}
		    		}
		    		else { //right
		    			switch (direction) {
		    			case 0:
		    				direction = 3;
		    				break;
		    			case 1:
		    				direction = 2;
		    				break;
		    			case 2:
		    				direction = 0;
		    				break;
		    			case 3:
		    				direction = 1;
		    				break;
		    			}
		    		}
		    		
		    	}
		    	
//		    	System.out.println(x + ", " + y  + " " + direction);
		    }
		    System.out.println(-1 * x + "," + y);
		    
		} catch (FileNotFoundException e) {
		    e.printStackTrace();
		} catch (IOException e) {
		    e.printStackTrace();
		} finally {
		    try {
		        if (reader != null) {
		            reader.close();
		        }
		        
		    } catch (IOException e) {
		    }
		}
	}

}
